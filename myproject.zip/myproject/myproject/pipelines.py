class SaveURLsPipeline:
    def open_spider(self, spider):
        # Open the file in write mode when the spider starts
        self.file = open("urls.txt", "w")

    def close_spider(self, spider):
        # Close the file when the spider ends
        self.file.close()

    def process_item(self, item, spider):
        # Write the URL to the file and add a newline
        self.file.write(item['url'] + "\n")
        return item
