import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

class MyCrawler(CrawlSpider):
    name = 'mycrawler'
    start_urls = ["https://www.sebi.gov.in/"]

    # Restrict to internal links by setting `allow_domains`
    rules = (
        Rule(
            LinkExtractor(
                allow_domains=["sebi.gov.in"]  # Only follow links from this domain
            ),
            callback="parse_item",
            follow=True,
        ),
    )

    def parse_item(self, response):
        # Log the URL being processed
        self.logger.info(f"Processing URL: {response.url}")
        # Yield the current URL
        yield {'url': response.url}
